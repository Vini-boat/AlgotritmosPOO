#include "Data.h"
#include <iostream>
#include <iomanip>

using namespace std;
Data::Data()
{
    dia = 0;
    mes = 0;
    ano = 0;
}

Data::Data(int dia, int mes, int ano)
{
    if ((dia <= 0) || (dia > 31))
    {
        dia = 0;
    }
    if ((mes <= 0) || (mes > 12))
    {
        mes = 0;
    }
    if ((ano <= 0) || (ano > 9999))
    {
        ano = 0;
    }
    this->dia = dia;
    this->mes = mes;
    this->ano = ano;
}

void Data::imprime_data()
{
    cout << setfill('0') << setw(2) << dia << "/" << mes << "/" << setw(4) << ano << endl;
}


Data::~Data(){}
