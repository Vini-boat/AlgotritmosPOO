#include <iostream>
#include "Data.h"

using namespace std;

int main()
{
    Data d (1,2,3);
    d.imprime_data();
    return 0;
}
