#include "Atleta.h"
#include <iostream>


using namespace std;
Atleta::Atleta()
{
    nome = "Padr�o";
    idade = 0;
}

Atleta::~Atleta(){}

Atleta::Atleta(string nome, int idade)
{
    this->nome = nome;
    this->idade = idade;
}

void Atleta::set_nome(string novo_nome)
{
    nome = novo_nome;
}
string Atleta::get_nome()
{
    return nome;
}

void Atleta::set_idade(int nova_idade)
{
    idade = nova_idade;
}
int Atleta::get_idade()
{
    return idade;
}

void Atleta::imprime_info()
{
    cout << "Atleta - Nome: " << nome << " Idade: " << idade;
}
