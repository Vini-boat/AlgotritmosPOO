#include "Nadador.h"
#include <iostream>

using namespace std;

Nadador::Nadador()
{
    nome = "Padr�o";
    idade = 0;
    categoria = "Padr�o";
}

Nadador::~Nadador(){}

Nadador::Nadador(string nome, int idade, string categoria)
{
    this->nome = nome;
    this->idade = idade;
    this->categoria = categoria;
}

void Nadador::imprime_info()
{
    Atleta::imprime_info();
    cout << " Categoria: " << categoria;
}
