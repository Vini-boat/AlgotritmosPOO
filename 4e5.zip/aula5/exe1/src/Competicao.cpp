#include "Competicao.h"

using namespace std;
Competicao::Competicao()
{
    nome = "Padr�o";
    data = Data();
}

Competicao::~Competicao(){}

Competicao::Competicao(string nome, Data data)
{
    this->nome = nome;
    this->data = data;
}

void Competicao::set_nome(string novo_nome)
{
    nome = novo_nome;
}
string Competicao::get_nome()
{
    return nome;
}

void Competicao::set_data(Data nova_data)
{
    data = nova_data;
}
Data Competicao::get_data()
{
    return data;
}

void Competicao::imprime_data(){
    data.imprime_data();
}
