#include "InformacoesAtleta.h"
#include <iostream>
#include "Atleta.h"
#include "Nadador.h"
#include "Corredor.h"

using namespace std;

InformacoesAtleta::InformacoesAtleta(){}
InformacoesAtleta::~InformacoesAtleta(){}


void InformacoesAtleta::imprime_exclusivos(Atleta *a)
{
    string tipo = a.get_tipo();
    if (tipo == "Corredor") imprime_nadador(a);
    if (tipo == "Nadador") imprime_nadador(a);
}
void InformacoesAtleta::imprime_nadador(Nadador *n)
{
    cout << "� um nadador, e sua categoria �: " << n.get_categoria();
}
void InformacoesAtleta::imprime_corredor(Corredor *c)
{
    cout << "� um corredor, e seu peso �: " << c.get_peso();
}
