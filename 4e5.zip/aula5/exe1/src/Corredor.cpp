#include "Corredor.h"
#include <string>
#include <iostream>

using namespace std;
Corredor::Corredor()
{
    nome = "Padr�o";
    idade = 0;
    peso = 0.0;
    competicao = Competicao();
}

Corredor::~Corredor(){}

Corredor::Corredor(string nome, int idade, float peso, Competicao competicao)
{
    this->nome = nome;
    this->idade = idade;
    this->peso = peso;
    this->competicao = competicao;
}

void Corredor::set_peso(float novo_peso)
{
    peso = novo_peso;
}
float Corredor::get_peso()
{
    return peso;
}

void Corredor::set_competicao(Competicao nova_competicao)
{
    competicao = nova_competicao;
}
Competicao Corredor::get_competicao()
{
    return competicao;
}

void Corredor::imprime_competicao()
{
    cout << "Competi��o: " << competicao.get_nome() << " Data: ";
    competicao.imprime_data();
}

string Corredor::get_tipo()
{
    return "Corredor";
}

void Corredor::imprime_info()
{
    Atleta::imprime_info();
    cout << " Peso: " << peso << endl;
    imprime_competicao();
}
