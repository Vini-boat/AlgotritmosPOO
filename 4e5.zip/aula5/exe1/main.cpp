#include <iostream>
#include "Atleta.h"
#include "Competicao.h"
#include "Data.h"
#include "Nadador.h"

using namespace std;

int main()
{
    Data dia_da_competicao(28,5,2004);
    Competicao copa("Copa do mundo", dia_da_competicao);

    Nadador felps("Michael Felps", 40, "Todas");

    copa.imprime_data();
    cout << endl;
    felps.imprime_info();

    return 0;
}
