#include <iostream>
#include "Competicao.h"
#include "Data.h"
#include "Corredor.h"

using namespace std;

int main()
{
    Data dia_da_competicao(28,5,2004);
    Competicao copa("Copa do mundo", dia_da_competicao);

    Corredor bolt("Usain", 40, 100.0,copa);

    bolt.imprime_info();

    return 0;
}
