#ifndef COMPETICAO_H
#define COMPETICAO_H
#include <string>
#include "Data.h"

using namespace std;
class Competicao
{
    public:
        Competicao();
        virtual ~Competicao();

        Competicao(string nome, Data data);

        void set_nome(string novo_nome);
        string get_nome();

        void set_data(Data nova_data);
        Data get_data();

        void imprime_data();

    private:
        string nome;
        Data data;
};

#endif // COMPETICAO_H
