#ifndef CORREDOR_H
#define CORREDOR_H
#include "Competicao.h"
#include "Atleta.h"
#include <string>

using namespace std;
class Corredor: Atleta
{
    public:
        Corredor();
        Corredor(string nome, int idade, float peso, Competicao competicao);
        virtual ~Corredor();

        void set_peso(float novo_peso);
        float get_peso();

        void set_competicao(Competicao nova_competicao);
        Competicao get_competicao();

        void imprime_competicao();
        void imprime_info();
    protected:

    private:
        float peso;
        Competicao competicao;
};

#endif // CORREDOR_H
