#ifndef DATA_H
#define DATA_H


class Data
{
    public:
        Data();
        Data(int dia, int mes, int ano);
        void imprime_data();
        virtual ~Data();

    private:
        int dia, mes, ano;
};

#endif // DATA_H
