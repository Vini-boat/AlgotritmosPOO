#ifndef INFORMACOESATLETA_H
#define INFORMACOESATLETA_H
#include "Atleta.h"
#include "Nadador.h"
#include "Corredor.h"

class InformacoesAtleta
{
    public:
        InformacoesAtleta();
        virtual ~InformacoesAtleta();
        void imprime_exclusivos(Atleta *a);
    protected:
        void imprime_nadador(Nadador *n);
        void imprime_corredor(Corredor *c);
    private:

};

#endif // INFORMACOESATLETA_H
