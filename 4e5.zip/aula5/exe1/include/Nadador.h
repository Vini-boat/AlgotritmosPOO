#ifndef NADADOR_H
#define NADADOR_H
#include <string>
#include "Atleta.h"

class Nadador: Atleta {
    public:
        Nadador();
        Nadador(string nome, int idade, string categoria);
        virtual ~Nadador();

        void set_categoria(string categoria);
        string get_categoria();

        void imprime_info();
    private:
        string categoria;
};

#endif // NADADOR_H
