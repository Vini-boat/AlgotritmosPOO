#ifndef ATLETA_H
#define ATLETA_H

#include <string>

using namespace std;
class Atleta
{
    public:
        Atleta();
        Atleta(string nome, int idade);
        virtual ~Atleta();

        void set_nome(string novo_nome);
        string get_nome();

        void set_idade(int nova_idade);
        int get_idade();

        void imprime_info();

        virtual string get_tipo();

    protected:
        string nome;
        int idade;


};

#endif // ATLETA_H
