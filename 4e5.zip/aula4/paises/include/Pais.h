#ifndef PAIS_H
#define PAIS_H

#include <string>
#include <vector>
using namespace std;
class Pais
{
    public:
        Pais(std::string codISO, std::string nome, float dimensao);
        Pais();
        virtual ~Pais();

        void set_codISO(std::string novo_codISO);
        std::string get_codISO();

        void set_nome(std::string novo_nome);
        std::string get_nome();

        void set_populacao(int nova_populacao);
        int get_populacao();

        void set_dimensao(float nova_dimensao);
        float get_dimensao();

        void set_vizinhos(vector<Pais> vizinhos);

        bool eh_igual_a(Pais pais);
        bool eh_vizinho_de(Pais pais);

        float densidade_populacional();

        vector<Pais> vizinhos_em_comum_com(Pais pais);

    private:
        std::string codISO;
        std::string nome;
        int populacao;
        float dimensao;
        vector<Pais> vizinhos;
};

#endif // PAIS_H
