#include "Pais.h"
#include <string>
#include <vector>

using namespace std;
Pais::Pais()
{
    codISO = "PAD";
    nome = "Padrao";
    populacao = 0;
    dimensao = 0.0;

}

Pais::Pais(std::string codISO, std::string nome,float dimensao)
{
    this->codISO = codISO;
    this->nome = nome;
    this->populacao = 0;
    this->dimensao = dimensao;

}

void Pais::set_codISO(std::string novo_codISO)
{
    codISO = novo_codISO;
}
std::string Pais::get_codISO()
{
    return codISO;
}

void Pais::set_nome(std::string novo_nome)
{
    nome = novo_nome;
}
std::string Pais::get_nome()
{
    return nome;
}

void Pais::set_populacao(int nova_populacao)
{
    populacao = nova_populacao;
}
int Pais::get_populacao()
{
    return populacao;
}

void Pais::set_dimensao(float nova_dimensao)
{
    dimensao = nova_dimensao;
}
float Pais::get_dimensao()
{
    return dimensao;
}

void Pais::set_vizinhos(vector<Pais> vizinhos)
{
    this->vizinhos = vizinhos;
}

bool Pais::eh_igual_a(Pais pais)
{
    return codISO == pais.codISO;
}
bool Pais::eh_vizinho_de(Pais pais)
{
    for(Pais p : vizinhos){
        if (pais.eh_igual_a(p)) return true;
    }
    return false;
}

float Pais::densidade_populacional()
{
    return populacao / dimensao;
}

vector<Pais> Pais::vizinhos_em_comum_com(Pais pais)
{
    vector<Pais> em_comum;
    for (Pais p : vizinhos){
        if(p.eh_vizinho_de(pais))
        {
            em_comum.push_back(p);
        }
    }
    return em_comum;
}

Pais::~Pais(){}
