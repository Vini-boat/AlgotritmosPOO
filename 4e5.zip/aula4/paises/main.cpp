#include <iostream>
#include "Pais.h"
#include <vector>
using namespace std;

int main()
{
    Pais brasil("BRA","Brasil",300);
    Pais argentina("ARG","Argentina",100);
    Pais equador("EQU", "Equador",50);

    brasil.set_vizinhos({argentina, equador});
    argentina.set_vizinhos({brasil});
    equador.set_vizinhos({brasil});

    vector<Pais> c = argentina.vizinhos_em_comum_com(equador);

    for(Pais p : c){
        cout << p.get_nome() << endl;
    }

    return 0;
}
